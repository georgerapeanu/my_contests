#include <bits/stdc++.h>

using namespace std;

const int INF = 1000;

enum SolutionType {
  BIT,
  CONNECT
};

enum ErrorType {
  OK,
  SEMI_OK,
  NO_FILE,
  BAD_OUTPUT,
  INCORECT
};

const char* errmsg[] = {"TO THE MOON!", "To the moon!-ish", "S-a furat fisierul de iesire", "Fisierul de iesire este o teapa", "HODL"};

void handleError(ErrorType err) {
  if(err == OK)
    printf("4");
  else if(err == SEMI_OK)
    printf("1");
  else
    printf("0");
  fprintf(stderr, "%s", errmsg[err]);
  exit(0);
}

struct Input {
private:
  int nrq;

public:
  Input(const char *str) {
    int n, t, x, y;
    nrq = 0;

    FILE *fin = fopen(str, "r");
    
    fscanf(fin, "%d", &n);
    for(int i = 0; i < n; ++i) {
      fscanf(fin, "%d", &t);
      if(t == 3) {
        fscanf(fin, "%d%d", &x, &y);
        ++this->nrq;
      } else
        fscanf(fin, "%d", &x);
    }
    
    fclose(fin);
  }

  int getNrq() {
    return this->nrq;
  }
};

struct Output {
private:
  SolutionType mode;
  int *rez;
  FILE *fin;
  char cursor;
  
  char getch() {
    this->cursor = fgetc(fin);
    while(this->cursor == ' ')
      this->cursor = fgetc(fin);
    return this->cursor;
  }

  void getnr(int &x) {
    bool negativ = false;
    x = 0;
    this->cursor = this->getch();
    
    if(!isdigit(this->cursor) && this->cursor != '-') {
      x = -2;
      return;
    }
    
    if(this->cursor == '-') {
      negativ = true;
      this->cursor = fgetc(this->fin);
    }
    if(!isdigit(this->cursor)) {
      x = -2;
      return;
    }

    while(isdigit(cursor) && x < INF) {
      x = x * 10 + this->cursor - '0';
      this->cursor = fgetc(this->fin);
    }

    if(this->cursor != ' ' && this->cursor != '\n') {
      x = -2;
      return;
    }

    if(negativ)
      x = -x;
  }

  bool endOfLine() {
    while(this->cursor == ' ')
      this->cursor = fgetc(fin);
    return this->cursor == '\n';
  }

  bool endOfFile() {
    while(this->cursor == ' ' || this->cursor == '\n')
      this->cursor = fgetc(fin);
    return this->cursor == EOF;
  }

  bool readWord(const char* str, int x) {
    for(int i = 0; i < x; ++i) {
      this->cursor = fgetc(this->fin);
      if(str[i] != this->cursor)
        return false;
    }
    return true;
  }

public:
  Output(const char *str, int nrq) {
    this->fin = fopen(str, "r");

    if(this->fin == NULL)
      handleError(NO_FILE);
    
    this->rez = new int[nrq];

    this->getch();
    
    if(this->cursor == 'b' && this->readWord("it", 2))
      this->mode = BIT;
    else if(this->cursor == 'c' && this->readWord("onnect", 6))
      this->mode = CONNECT;
    else
      handleError(BAD_OUTPUT);
    
    this->cursor = fgetc(fin);
    
    if(!this->endOfLine())
      handleError(BAD_OUTPUT);
    
    for(int i = 0; i < nrq; ++i) {
      this->getnr(rez[i]);
      if(rez[i] == -2)
        handleError(BAD_OUTPUT);
      if(!this->endOfLine())
        handleError(BAD_OUTPUT);
    }

    if(!this->endOfFile())
      handleError(BAD_OUTPUT);
  }

  ~Output() {
    if(fin != NULL)
      fclose(fin);
    delete[] rez;
  }

  SolutionType getMode() {
    return this->mode;
  }
  
  int getRez(int i) {
    return this->rez[i];
  }
};

int main() {
  Input *inp = new Input("bitconnect.in");
  Output *out = new Output("bitconnect.out", inp->getNrq()),
         *ok  = new Output("bitconnect.ok" , inp->getNrq());

  if(out->getMode() == CONNECT) {
    for(int i = 0; i < inp->getNrq(); ++i)
      if(out->getRez(i) != (ok->getRez(i) != -1))
        handleError(INCORECT);
    handleError(SEMI_OK);
  } else {
    for(int i = 0; i < inp->getNrq(); ++i)
      if(out->getRez(i) != ok->getRez(i))
        handleError(INCORECT);
    handleError(OK);
  }
  return 0;
}

